package com.javatechie.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudK8sExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
