package com.javatechie.crud.OrderService.repository;

import com.javatechie.crud.OrderService.repository.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Integer> {
}
