package com.javatechie.crud.CartService;

import org.springframework.web.bind.annotation.PostMapping;

public class testCart {
    String url = "http://example.test/orderservice/{id}";
    Integer empId= 101;
//    Employee emp = restTemplate.getForObject(url, Employee.class, empId);
}
