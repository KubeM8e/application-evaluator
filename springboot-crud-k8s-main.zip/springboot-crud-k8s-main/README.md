# springboot-crud-k8s
Run &amp; Deploy Spring Boot CRUD Application With MySQL on K8S
